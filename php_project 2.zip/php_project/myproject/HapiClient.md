

Here is the reformatted text in Markdown format:

### Overview

The following HapiClient classes were tested as they are present in CAPI Code:

* `HapiClient\Hal\Resource`
* `HapiClient\Hal\Link`
* `HapiClient\Http\HapiClient`
* `HapiClient\Http\Auth\Oauth2BasicAuthentication`
* `HapiClient\Http\Exception\HttpException`
* `HapiClient\Hal\ResourceInterface`
* `HapiClient\Hal\ClientInterface`

### Installation

To use the HapiClient classes, you need to install the HapiClient library. Here are the steps to install the library:

1. First, you need to add the HapiClient library to your project's dependencies. You can do this by adding the following line to your `composer.json` file:
```json
{
  "require": {
    "slimpay/hapiclient-guzzle7": "1.0.*"
  }
}
```
2. Save the `composer.json` file and run the following command to install the library:
```bash
composer install
```

### Conclusion
After testing the HapiClient library, we found that there were no deprecated code issues. The library can be used with PHP 8.3 without requiring any code migration. Additionally, we did not need to use Rector to resolve any compatibility issues. 