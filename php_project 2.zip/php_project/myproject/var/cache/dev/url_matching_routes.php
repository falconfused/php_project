<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\UserController::index'], null, ['GET' => 0], null, false, false, null]],
        '/create-user' => [[['_route' => 'create_user', '_controller' => 'App\\Controller\\UserController::createUser'], null, ['POST' => 0], null, false, false, null]],
        '/user/generate-pdf' => [[['_route' => 'user_generate_pdf', '_controller' => 'App\\Controller\\UserController::generatePdf'], null, ['GET' => 0], null, false, false, null]],
        '/boundary' => [[['_route' => 'boundary', '_controller' => 'App\\Controller\\UserController::someFunction'], null, ['GET' => 0], null, false, false, null]],
        '/test-serializable' => [[['_route' => 'test_serializable', '_controller' => 'App\\Controller\\UserController::testSerializable'], null, ['GET' => 0], null, false, false, null]],
        '/link' => [[['_route' => 'get_link', '_controller' => 'App\\Controller\\UserController::getLink'], null, ['GET' => 0], null, false, false, null]],
        '/link/from-json' => [[['_route' => 'get_link_from_json', '_controller' => 'App\\Controller\\UserController::getLinkFromJson'], null, ['GET' => 0], null, false, false, null]],
        '/resource/state' => [[['_route' => 'get_state', '_controller' => 'App\\Controller\\UserController::getState'], null, ['GET' => 0], null, false, false, null]],
        '/resource/links' => [[['_route' => 'get_all_links', '_controller' => 'App\\Controller\\UserController::getAllLinks'], null, ['GET' => 0], null, false, false, null]],
        '/resource/embedded' => [[['_route' => 'get_all_embedded_resources', '_controller' => 'App\\Controller\\UserController::getAllEmbeddedResources'], null, ['GET' => 0], null, false, false, null]],
        '/oauth2-basic-authentication' => [[['_route' => 'create_oauth2_basic_authentication', '_controller' => 'App\\Controller\\UserController::createOauth2BasicAuthentication'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/users/(?'
                    .'|(\\d+)(*:184)'
                    .'|([^/]++)/(?'
                        .'|edit(*:208)'
                        .'|delete(*:222)'
                    .')'
                .')'
                .'|/resource/links/([a-zA-Z0-9_]+)(*:263)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        184 => [[['_route' => 'show_user', '_controller' => 'App\\Controller\\UserController::getUserById'], ['userId'], ['GET' => 0], null, false, true, null]],
        208 => [[['_route' => 'edit_user', '_controller' => 'App\\Controller\\UserController::editUser'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        222 => [[['_route' => 'delete_user', '_controller' => 'App\\Controller\\UserController::deleteUser'], ['id'], ['POST' => 0], null, false, false, null]],
        263 => [
            [['_route' => 'get_links', '_controller' => 'App\\Controller\\UserController::getLinks'], ['rel'], ['GET' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
