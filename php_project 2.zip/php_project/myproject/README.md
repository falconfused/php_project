 <!-- 1. Installed composer and php 7.4
2. Created a project using symfony 5.4
3. Used Doctrine framework for database and postgres database and created a basic crud application
4. to upgrade first ran composer require rector/rector --dev to install rector
5. then ran ./vendor/bin/rector to create rector file
Code for rector to upgrade symfony and php version of the code:
<?php

declare(strict_types=1);

use Rector\Config\RectorConfig;
use Rector\Symfony\Set\SymfonySetList;
use Rector\Set\ValueObject\LevelSetList;

return static function (RectorConfig $rectorConfig): void {
    $rectorConfig->paths([
        __DIR__ . '/config',
        __DIR__ . '/public',
        __DIR__ . '/src',
        __DIR__ . '/tests',
    ]);

    // Apply a predefined set for PHP 8.2 upgrade
    $rectorConfig->sets([
        LevelSetList::UP_TO_PHP_82,        // Ensure compatibility with PHP 8.2
        SymfonySetList::SYMFONY_60,        // Ensure compatibility with Symfony 6
    ]);

    // Additional configuration as needed
};
6. upgraded version of php and symfony using composer and in composer.json file
7. then ran ./vendor/bin/rector  to upgrade code as per symfony 6 and php 8.1
 -->








# Project Setup and Upgrade Guide

## Step 1: Install Composer and PHP 7.4


First, ensure you have Composer and PHP 7.4 installed on your system.

## Step 2: Create a New Symfony Project


Create a new project using Symfony 5.4 by running the following command:
```bash
composer create-project symfony/skeleton myproject
```
Replace `myproject` with your desired project name.

## Step 3: Configure Doctrine and Postgres Database
-------------------------------------------------

Install the Doctrine framework and configure it to use a Postgres database.

## Step 4: Create a Basic CRUD Application
---------------------------------------------

Create a basic CRUD (Create, Read, Update, Delete) application 

## Step 5: Install Rector for Code Upgrade
---------------------------------------------

To upgrade your code to PHP 8.2, install Rector by running the following command:
```bash
composer require rector/rector --dev
```
## Step 6: Create Rector Configuration File
---------------------------------------------

Run the following command to create a Rector configuration file:
```bash
./vendor/bin/rector
```
This will generate a `rector.php` file in your project root.

## Step 7: Configure Rector for PHP 8.2 Upgrade
------------------------------------------------

Update the `rector.php` file to include the following configuration:
```php
<?php

declare(strict_types=1);

use Rector\Config\RectorConfig;
use Rector\Symfony\Set\SymfonySetList;
use Rector\Set\ValueObject\LevelSetList;

return static function (RectorConfig $rectorConfig): void {
    $rectorConfig->paths([
        __DIR__ . '/config',
        __DIR__ . '/public',
        __DIR__ . '/src',
        __DIR__ . '/tests',
    ]);

    // Apply a predefined set for PHP 8.2 upgrade
    $rectorConfig->sets([
        LevelSetList::UP_TO_PHP_82,        // Ensure compatibility with PHP 8.2
    ]);

    // Additional configuration as needed
};
```
## Step 8: Upgrade Code using Rector
--------------------------------------

Run the following command to upgrade your code to PHP 8.2:
```bash
./vendor/bin/rector
```
This will apply the Rector configuration and upgrade your code accordingly.






## After Cloning the liitlerocket\PHPPdf Library: A Detailed Account of Upgrading to PHP 8.2 using Rector




### Cloning the liitlerocket\PHPPdf Library

We began by cloning the liitlerocket\PHPPdf library into our project directory. 

### Attempting to Use the Library in PHP 7.4

After cloning the library, we attempted to use it in our PHP 7.4 environment. We created a test script that instantiated the library's `1` class and used it.

### Upgrading the Code to PHP 8.2 using Rector

We then ran the Rector command to upgrade the code. Rector analyzed the library's codebase, identified areas that needed to be updated, and applied the necessary changes. Although there were no such areas which had deprecated code in it.

### Targeting the Library's Codebase

During the upgrade process, we specifically targeted the library's codebase, which only utilized two classes: `1` and `2`. 

### Results of the Upgrade

After running the Rector command, we reviewed the upgraded code and were pleased to find that there were no deprecated code sections detected. The library's codebase had been successfully upgraded to PHP 8.2, and all compatibility issues had been resolved. We were impressed by Rector's accuracy and efficiency in handling the upgrade process.

