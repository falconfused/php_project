<?php

declare(strict_types=1);

use Rector\Config\RectorConfig;
use Rector\Symfony\Set\SymfonySetList;
use Rector\Set\ValueObject\LevelSetList;

return static function (RectorConfig $rectorConfig): void {
    $rectorConfig->paths([
        __DIR__ . '/config',
        __DIR__ . '/public',
        __DIR__ . '/src',
        __DIR__ . '/tests',
        __DIR__ . '/jms',
    ]);

    // Apply a predefined set for PHP 8.1 upgrade
    $rectorConfig->sets([
        LevelSetList::UP_TO_PHP_81,        // Ensure compatibility with PHP 8.2
        SymfonySetList::SYMFONY_60,        // Ensure compatibility with Symfony 6
    ]);

    // Additional configuration as needed
};
