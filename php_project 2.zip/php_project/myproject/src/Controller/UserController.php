<?php
namespace App\Controller;

use App\Entity\User;
use HapiClient\Hal\Resource;
use HapiClient\Hal\Link;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use HapiClient\Http\HapiClient;
use HapiClient\Http\Auth\Oauth2BasicAuthentication;

use PHPPdf\Core\Boundary;
use PHPPdf\Core\Document;
use PHPPdf\Core\Engine\EngineInterface;
use PHPPdf\Core\Engine\ZendEngine;
use PHPPdf\Core\Node\Chart;
use PHPPdf\Core\Point;

class UserController extends AbstractController
{

    // private $workflowExtensionsBundle;

    // public function __construct(WorkflowExtensionsBundle $workflowExtensionsBundle)
    // {
    //     $this->workflowExtensionsBundle = $workflowExtensionsBundle;
    // }

    // public function someFunction()
    // {
    //     $test_variable = "Hello World";
    //     if($test_variable instanceof ScheduledJob) {
    //         echo "Hello World";
    //     }
    //     else
    //         {
    //             echo "Hello Not World";
    //         }
    //     // Now you can use the workflow
    //     // ...
    // }


    // public function index()
    // {
    //     // Use the workflowExtensionsBundle service
    //     $result = $this->workflowExtensionsBundle->someMethod();
    //     return new Response($result);
    // }
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    // public function index()
    // {
    //     // Return a response, for example:
    //     return $this->json(['message' => 'Welcome to the homepage!']);
    // }

    public function createUser()
    {
        // Create a new User entity
        $user = new User();
        $user->setName('John Doe');
        $user->setEmail('john.doe@example.com');
        $user->setPassword('password123');

        // Save the User entity to the database
        $this->entityManager->persist($user);
        $this->entityManager->flush();

        // Return a response (optional)
        return $this->json([
            'message' => 'User created successfully!',
            'user' => $user
        ]);
    }

    public function getUserById(int $userId)
    {
        // Retrieve a User entity by ID
        $user = $this->entityManager->getRepository(User::class)->find($userId);

        // Check if user was found
        if (!$user) {
            throw $this->createNotFoundException(
                'No user found for id ' . $userId
            );
        }

        // Assume the User entity has a 'status' field
        $status = $user->getStatus();

        // Use the deprecated each() function (not available in PHP 8.1)
        $statusArray = [
            'active' => 'User is active.',
            'inactive' => 'User is inactive.',
            'banned' => 'User is banned.'
        ];
        
        reset($statusArray);
        foreach ($statusArray as $key => $message) {
            if ($key === $status) {
                $statusMessage = $message;
                break;
            }
        }
        
        if (!isset($statusMessage)) {
            $statusMessage = 'User status is unknown.';
        }

        // Return the response with the user status message
        return $this->json([
            'user_email' => $user->getEmail(),
            'status_message' => $statusMessage,
        ]);
    }

    public function generatePdf(): Response
    {
        $engine = new ZendEngine();
        $document = new Document($engine);

        // Create a new page
        $page = $document->addPage();

        // Add some content to the page
        $page->addText('Hello, World!', 10, 10);

        // Save the document to a file
        $document->save('example.pdf');

        // Return a response with the PDF file
        return new Response(file_get_contents('example.pdf'), 200, [
            'Content-Type' => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="example.pdf"',
        ]);
    }

//     public function generatePdf(EntityManagerInterface $entityManager): Response
// {
//     // Create a new document
//     $document = new Document();

//     // Add a page to the document
//     $page = $document->addPage();

//     // Add a text node to the page
//     $text = new Node\Text('Hello World!');
//     $page->addChild($text);

//     // Generate the PDF content
//     $pdfContent = $document->render();

//     // Create a response with the PDF content
//     return new Response($pdfContent, 200, [
//         'Content-Type' => 'application/pdf',
//         'Content-Disposition' => 'inline; filename="my_pdf.pdf"',
//     ]);
// }


    public function testSerialize()
    {
        $boundary = new Boundary();
        $boundary->setNext(10, 20);
        $boundary->setNext(30, 40);
        $boundary->setNext(50, 60);

        $serializedBoundary = $boundary->serialize();

        // Store the serialized boundary in a database or file
        // For example:
        // DB::table('boundaries')->insert(['data' => $serializedBoundary]);

        // Later, retrieve the serialized boundary from the database or file
        // For example:
        // $serializedBoundary = DB::table('boundaries')->first()->data;

        $unserializedBoundary = new Boundary();
        $unserializedBoundary->unserialize($serializedBoundary);

        // Now you can use the unserialized boundary
        var_dump($unserializedBoundary->getPoints());
    }

    public function testOffsetUnset()
    {
        $point = Point::getInstance(10, 20);
        
        try {
            $point->offsetUnset(0);
        } catch (BadMethodCallException $e) {
            echo $e->getMessage(); // Outputs: PHPPdf\Core\Point class is inmutable.
        }
    }
    public function getLink() {
        // Create a new Link object
        $link = new Link(
            'https://example.com', 
            true, 
            'application/json', 
            null, 
            'example', 
            'https://example.com/profile', 
            'Example Link', 
            'en-US'
        );

        // You can now use the Link object as needed
        // For example, you can return it as a response
        $response = new Response();
    $response->setContent($link);

    // You can now return the Response object
    return $response;
    }

    public function getLinkFromJson() {
        // Create a new Link object from a JSON string
        $json = '{
            "href": "https://example.com",
            "templated": true,
            "type": "application/json",
            "deprecation": null,
            "name": "example",
            "profile": "https://example.com/profile",
            "title": "Example Link",
            "hreflang": "en-US"
        }';

        $link = Link::fromJson($json);

        // You can now use the Link object as needed
        // For example, you can return it as a response
        $response = new Response();
    $response->setContent($link);

    // You can now return the Response object
    return $response;
    }
    public function getResource($rel)
    {
        $resource = new Resource();
        try {
            $resource = $resource->getEmbeddedResource($rel);
        } catch (RelNotFoundException $e) {
            return new JsonResponse(['error' => 'Relation not found'], 404);
        } catch (EmbeddedResourceNotUniqueException $e) {
            return new JsonResponse(['error' => 'Multiple resources found'], 400);
        }

        return new JsonResponse($resource->getState());
    }

    public function getLinks($rel)
    {
        $resource = new Resource();
        try {
            $links = $resource->getLinks($rel);
        } catch (RelNotFoundException $e) {
            return new JsonResponse(['error' => 'Relation not found'], 404);
        } catch (LinkUniqueException $e) {
            return new JsonResponse(['error' => 'Multiple links found'], 400);
        }

        return new JsonResponse($links);
    }

    
    public function getState()
    {
        $resource = new Resource();
        return new JsonResponse($resource->getState());
    }

    public function getAllLinks()
    {
        $resource = new Resource();
        return new JsonResponse($resource->getAllLinks());
    }

    public function getAllEmbeddedResources()
    {
        $resource = new Resource();
        return new JsonResponse($resource->getAllEmbeddedResources());
    }

    public function createOauth2BasicAuthentication() {
        // Create an instance of HapiClient
        $hapiClient = new HapiClient();

        // Set the token endpoint URL, userid, password, scope, and grant type
        $tokenEndPointUrl = 'https://example.com/token';
        $userid = 'your_userid';
        $password = 'your_password';
        $scope = 'api';
        $grantType = 'client_credentials';

        // Create an instance of Oauth2BasicAuthentication
        $oauth2BasicAuthentication = new Oauth2BasicAuthentication(
            $tokenEndPointUrl,
            $userid,
            $password,
            $scope,
            $grantType,
            null
        );
        $responseContent = json_encode($oauth2BasicAuthentication);

        return new Response($responseContent);

        // You can now use the $oauth2BasicAuthentication instance
        // to authorize requests, get access tokens, etc.
    }
}
